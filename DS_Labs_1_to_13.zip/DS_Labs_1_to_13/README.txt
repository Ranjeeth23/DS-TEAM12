# Data Science Labs 1–13 (Google Colab)

This folder contains 13 separate Jupyter notebooks based on the uploaded Data Science lab manuals.

## Run in Google Colab
1. Download and extract `DS_Labs_1_to_13.zip`.
2. Open https://colab.research.google.com/
3. Select **File → Upload notebook**.
4. Upload `Lab_01.ipynb` (or any lab).
5. Select **Runtime → Run all**.
6. Repeat for Labs 2–13.

## Included labs
1. Anaconda installation / Python environment check
2. Data cleaning
3. Similarity and dissimilarity measures
4. Data science workflow and processing pipeline
5. Data transformation and dimensionality reduction
6. Exploratory data analysis and statistical measures
7. Data visualization
8. Linear algebra and matrix decomposition
9. Probability distributions and hypothesis testing
10. Regression models
11. Classification and evaluation metrics
12. Unsupervised learning and clustering
13. Text analytics and movie recommendation

## Notes
- Lab 1 checks the Python environment in Colab; Anaconda itself is installed on a local computer, not inside the hosted Colab runtime.
- The notebooks use small sample or built-in datasets so they can run without uploading separate dataset files.
- Internet access is not required for the notebook code, except when opening Google Colab itself.
- Some outputs can differ slightly across library versions.
